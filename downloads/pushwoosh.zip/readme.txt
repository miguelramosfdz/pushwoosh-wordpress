=== Plugin Name ===
Website link: http://www.pushwoosh.com
Tags: pushwoosh, push notifications, push
Arello Mobile: http://www.arello-mobile.com
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Push notifications plugin for Wordpress by Pushwoosh. Send push notifications when you publish or update a post or a page.

== Description ==

Push notifications plugin for Wordpress by Pushwoosh.
Gives you an ability to send push notifications when you publish or update a post or a page.
The plugin uses Pushwoosh Remote API. Please note that you have to have a Premium account on Pushwoosh.
You have to have mobile app for your wordpress website as well. There are quite a few providers that allows to create such an app.
http://www.pushwoosh.com

== Installation ==

1. Download the pushwoosh plugin
2. Unzip and upload to your plugins directory ("/wp-content/plugins/"" is default)
3. Configure via the settings page (Set Pushwoosh Application Code and Auth Token)
4. That's it!
